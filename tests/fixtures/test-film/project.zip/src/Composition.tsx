import React from 'react';
import {AbsoluteFill,useCurrentFrame} from 'remotion';
export const COMPOSITION_FPS = 30;
export const COMPOSITION_DURATION_IN_FRAMES = 12925;
export const COMPOSITION_WIDTH = 1920;
export const COMPOSITION_HEIGHT = 1080;

const ink='#493125',deep='#2F2019',rust='#B85C38',gold='#D69A3B',cream='#FFF6E6',green='#737C50',sand='#E6D3B3',tan='#C8AC88',edge='#D6B99A',clay='#CF7956',wood='#A77F60',mute='#D7C6AC';
const cues=[{"id":0,"at":0},{"id":1,"at":10},{"id":2,"at":22},{"id":3,"at":35},{"id":4,"at":47.45},{"id":5,"at":85.8},{"id":6,"at":97.7},{"id":7,"at":108.13333333333333},{"id":8,"at":112.13333333333333},{"id":10,"at":122.03333333333332},{"id":11,"at":135.63333333333333},{"id":12,"at":144.23333333333335},{"id":13,"at":154.23333333333335},{"id":14,"at":171.83333333333331},{"id":15,"at":180.73333333333335},{"id":16,"at":191.26666666666665},{"id":17,"at":201.66666666666669},{"id":18,"at":208.9666666666667},{"id":19,"at":218.4666666666667},{"id":20,"at":229.76666666666665},{"id":21,"at":247.36666666666667},{"id":22,"at":265.4},{"id":23,"at":278.8},{"id":24,"at":293.36666666666673},{"id":25,"at":302.2666666666667},{"id":26,"at":312.7666666666667},{"id":27,"at":320.1333333333334},{"id":28,"at":333.3},{"id":29,"at":341.43333333333334},{"id":30,"at":364.93333333333334},{"id":31,"at":380.6333333333333},{"id":32,"at":397.8333333333333},{"id":33,"at":410.73333333333335},{"id":34,"at":414.8333333333333}];

// ---------- easing ----------
const cl=(v:number,a=0,b=1)=>Math.min(b,Math.max(a,v));
const io=(x:number)=>{x=cl(x);return x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2};
const oc=(x:number)=>{x=cl(x);return 1-Math.pow(1-x,3)};
const ap=(t:number,d=0,l=.7)=>oc((t-d)/l);
const fl=(t:number,i=0,a=8)=>Math.sin(t*1.1+i*1.7)*a;
const blink=(t:number,i=0)=>((t+i*.73)%3.4)<.12?.12:1;
const rp=(cx:number,cy:number,dx:number,dy:number,deg:number)=>{const a=deg*Math.PI/180;return [cx+dx*Math.cos(a)-dy*Math.sin(a),cy+dx*Math.sin(a)+dy*Math.cos(a)]};

// ---------- node builders (every node is keyed; same key in adjacent scenes = magic move) ----------
const R=(k:string,x:number,y:number,w:number,h:number,fill:any,o:any={})=>({k,t:'rect',x,y,w,h,fill,rx:12,...o});
const C=(k:string,x:number,y:number,r:number,fill:any,o:any={})=>R(k,x,y,r*2,r*2,fill,{rx:r,...o});
const E=(k:string,x:number,y:number,w:number,h:number,fill:any,o:any={})=>R(k,x,y,w,h,fill,{rx:w/2,ry:h/2,...o});
const X=(k:string,x:number,y:number,text:string,size=56,fill=ink,o:any={})=>({k,t:'text',x,y,text,size,fill,...o});
const P=(k:string,d:string,stroke:any,o:any={})=>({k,t:'path',x:0,y:0,d,stroke,sw:6,fill:'none',...o});
const I=(k:string,icon:string,x:number,y:number,s=1,o:any={})=>({k,t:'icon',icon,x,y,s,...o});
const H=(k:string,text:string)=>X(k,960,190,text,56,ink,{weight:700});

// ---------- icons ----------
const starD=(()=>{let d='';for(let i=0;i<10;i++){const r=i%2?44:100,a=-Math.PI/2+i*Math.PI/5;d+=(i?'L':'M')+(r*Math.cos(a)).toFixed(1)+' '+(r*Math.sin(a)).toFixed(1)+' ';}return d+'Z'})();
const icon=(n:any)=>{const c=n.fill||ink,c2=n.c2||gold,e=n.e??1;switch(n.icon){
case 'star':return <><path d={starD} fill={c} stroke={c} strokeWidth="22" strokeLinejoin="round"/><path d={starD} transform="translate(-10 -12) scale(.42)" fill={cream} opacity=".28"/><circle cx="58" cy="-78" r="9" fill={c} opacity=".7"/><path d="M-96 -96 l0 -26 m-13 13 l26 0" stroke={c} strokeWidth="6" strokeLinecap="round" opacity=".7"/></>;
case 'note':return <g fill={c}><ellipse cx="-40" cy="38" rx="25" ry="18" transform="rotate(-22 -40 38)"/><ellipse cx="44" cy="22" rx="25" ry="18" transform="rotate(-22 44 22)"/><rect x="-24" y="-64" width="9" height="100" rx="4"/><rect x="60" y="-80" width="9" height="100" rx="4"/><path d="M-24 -64 L69 -80 L69 -54 L-24 -38Z"/></g>;
case 'note1':return <g fill={c}><ellipse rx="24" ry="17" transform="rotate(-22)"/><rect x="14" y="-92" width="8" height="92" rx="4"/><path d="M18 -92 Q62 -76 46 -34 Q46 -60 18 -62Z"/></g>;
case 'pen':return <><rect x="-22" y="-150" width="44" height="160" rx="22" fill={c}/><rect x="-22" y="-72" width="44" height="14" fill={c2}/><rect x="-9" y="-140" width="8" height="60" rx="4" fill={cream} opacity=".3"/><path d="M-22 4 L22 4 L4 92 L-4 92Z" fill={c2}/><path d="M0 32 L0 86" stroke={deep} strokeWidth="3"/><circle cy="32" r="5" fill={deep}/></>;
case 'bot':return <><ellipse cy="108" rx="78" ry="11" fill={ink} opacity=".12"/><path d="M0 -66 L0 -94" stroke={c} strokeWidth="8" strokeLinecap="round"/><circle cy="-102" r="13" fill={c2}/><rect x="-98" y="-24" width="18" height="50" rx="9" fill={c}/><rect x="80" y="-24" width="18" height="50" rx="9" fill={c}/><rect x="-84" y="-68" width="168" height="142" rx="46" fill={c}/><rect x="-66" y="-58" width="54" height="10" rx="5" fill={cream} opacity=".3"/><rect x="-62" y="-42" width="124" height="82" rx="30" fill={deep}/><rect x="-35" y={-9-13*e} width="18" height={26*e} rx="9" fill={c2}/><rect x="17" y={-9-13*e} width="18" height={26*e} rx="9" fill={c2}/><path d="M-13 22 Q0 30 13 22" stroke={c2} strokeWidth="4" fill="none" strokeLinecap="round"/><rect x="-46" y="76" width="92" height="20" rx="10" fill={c} opacity=".8"/></>;
}return null};

// ---------- drawing & interpolation ----------
const f2=(v:number)=>Math.round(v*100)/100;
const draw=(n:any,key:string)=>{const o=n.o??1;if(o<=.004)return null;const s=n.s??1;const tr='translate('+f2(n.x)+' '+f2(n.y)+')'+(n.rot?' rotate('+f2(n.rot)+')':'')+(s!==1?' scale('+f2(s)+')':'');let b:any=null;
if(n.t==='rect'){const w=Math.max(0,n.w),h=Math.max(0,n.h),rx=Math.min(n.rx||0,w/2),ry=Math.min(n.ry??n.rx??0,h/2);b=<>{n.sh?<rect x={-w/2+10} y={-h/2+14} width={w} height={h} rx={rx} ry={ry} fill={ink} opacity={f2(.1*n.sh)}/>:null}<rect x={-w/2} y={-h/2} width={w} height={h} rx={rx} ry={ry} fill={n.fill||'none'} stroke={n.stroke||'none'} strokeWidth={n.sw||0}/></>}
else if(n.t==='text')b=<text y={f2(n.size*.35)} textAnchor={n.anchor||'middle'} fill={n.fill} fontSize={f2(n.size)} fontWeight={n.weight||600} letterSpacing={n.ls||0}>{n.text}</text>;
else if(n.t==='path')b=<path d={n.d} fill={n.fill||'none'} stroke={n.stroke||'none'} strokeWidth={n.sw||0} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={n.dash||'none'} strokeDashoffset={n.off||0}/>;
else b=icon(n);
return <g key={key} transform={tr} opacity={f2(Math.min(1,o))}>{b}</g>};
const NUM=['x','y','w','h','rx','ry','rot','s','o','size','sw','off','sh','e','ls'];
const DEF:any={rot:0,s:1,o:1,sw:0,off:0,sh:0,e:1,ls:0};
const hx=(c:string)=>[1,3,5].map(i=>parseInt(c.slice(i,i+2),16));
const mixC=(a:any,b:any,p:number)=>{if(typeof a!=='string'||typeof b!=='string'||a.length!==7||b.length!==7||a[0]!=='#'||b[0]!=='#')return p<.5?a:b;const A=hx(a),B=hx(b);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*p).toString(16).padStart(2,'0')).join('')};
const mix=(a:any,b:any,p:number)=>{const r:any={...b};for(const k of NUM){const va=a[k]??(k==='ry'?a.rx:DEF[k]),vb=b[k]??(k==='ry'?b.rx:DEF[k]);if(va!==undefined&&vb!==undefined)r[k]=va+(vb-va)*p;}for(const k of ['fill','stroke','c2'])r[k]=mixC(a[k],b[k],p);return r};
const D=1.2;
const compose=(A:any[]|null,B:any[],u:number)=>{if(!A||u>=1)return B.map(n=>draw(n,n.k));
 const am=new Map(A.map(n=>[n.k,n])),bm=new Map(B.map(n=>[n.k,n]));const out:any[]=[];
 // text whose words change dissolves out, then in at its new place, instead of sliding through other copy
 const swap=(a:any,b:any)=>a.t==='text'&&a.text!==b.text;
 A.forEach(a=>{const b:any=bm.get(a.k);if(b&&b.t===a.t&&!swap(a,b))return;const p=b&&b.t===a.t?io(u/.4):io(u/.65);out.push(draw({...a,o:(a.o??1)*(1-p),s:(a.s??1)*(1-.06*p)},'a_'+a.k))});
 let j=0,m=0;
 B.forEach(b=>{const a:any=am.get(b.k);
  if(a&&a.t===b.t&&swap(a,b)){const q=io((u-.38)/.5);out.push(draw({...b,o:(b.o??1)*q,y:b.y+(1-q)*14},b.k));}
  else if(a&&a.t===b.t){const d=Math.min(j++,20)*.01,p=io((u-d)/.8),mm=mix(a,b,p);
   const same=a.t==='text'?a.text===b.text:a.t==='icon'?a.icon===b.icon:a.t==='path'?(a.d===b.d&&a.dash===b.dash):true;
   if(same)out.push(draw(mm,b.k));else{out.push(draw({...mm,text:a.text,icon:a.icon,d:a.d,dash:a.dash,o:mm.o*(1-p)},'x_'+b.k));out.push(draw({...mm,o:mm.o*p},b.k));}
  }else{const q=io((u-.22-Math.min(m++,20)*.012)/.55);out.push(draw({...b,o:(b.o??1)*q,s:(b.s??1)*(.94+.06*q),y:b.y+(1-q)*26},b.k));}
 });return out};

// ---------- shared pieces ----------
const clock=(cx:number,cy:number,t:number,ring:string,speed:number)=>[
 R('display',cx,cy,460,460,cream,{rx:230,stroke:ring,sw:14,sh:1}),
 ...Array.from({length:12},(_,i)=>{const a=i*Math.PI/6;return R('tick'+i,cx+182*Math.sin(a),cy-182*Math.cos(a),i%3?8:14,i%3?20:34,i%3?tan:ink,{rx:4,rot:i*30})}),
 P('hh','M0 18 L0 -100',ink,{x:cx,y:cy,sw:16,rot:t*speed/6}),
 P('mh','M0 24 L0 -158',rust,{x:cx,y:cy,sw:9,rot:t*speed}),
 C('hub',cx,cy,16,gold)];
const strW=(s:string)=>Array.from(s).reduce((w,c)=>w+(c===' '?14:40),0);

const scene=(id:number,t:number):any[]=>{switch(id){
case 0:return [
 C('halo2',960,400,330,gold,{o:.06}),
 C('halo',960,400,240,gold,{o:.13+.04*Math.sin(t*1.5)}),
 I('star','star',960,400,1.45+.03*Math.sin(t*1.6),{fill:gold,rot:Math.sin(t*.7)*4}),
 ...[[470,330,ink],[1440,300,rust],[640,560,rust],[1300,560,ink]].map(([x,y,c]:any,i)=>I('note'+i,'note',x,y+fl(t,i,20),.72,{fill:c,rot:(i%2?8:-8)+Math.sin(t+i)*5})),
 X('title',960,700,'让《汉密尔顿》唱中文',92,ink,{weight:700}),
 R('rule',960,772,190*ap(t,.8,.9),5,rust,{rx:3}),
 X('sub',960,826,'一名程序员的填词实验',32,rust,{ls:8})];
case 1:{const op=ap(t,.8,2.6),cw=560*(1-.66*op);return [
 R('stage',960,480,1320,660,rust,{rx:36,sh:1}),
 R('screen',960,540,1120,500,deep,{rx:14}),
 P('beam','M890 290 L1030 290 L1250 790 L670 790 Z',null,{fill:gold,o:.16*op}),
 E('pool',960,762,520,64,gold,{o:.25*op}),
 I('star','star',960,580,.82,{fill:gold,rot:Math.sin(t*.7)*3}),
 R('curL',400+cw/2,540,cw,500,clay,{rx:10}),R('curR',1520-cw/2,540,cw,500,clay,{rx:10}),
 ...[1,2,3].flatMap(i=>[R('fL'+i,400+cw*i/4,540,6,480,'#B05A3A',{rx:3,o:.6}),R('fR'+i,1520-cw*i/4,540,6,480,'#B05A3A',{rx:3,o:.6})]),
 R('valance',960,304,1120,40,'#9E4A2C',{rx:10}),
 ...[380,432,484,536,588,640,1280,1332,1384,1436,1488,1540].map((x,i)=>C('bulb'+i,x,190,9,cream,{o:.45+.55*Math.abs(Math.sin(t*2.5+i*.8))})),
 R('sign',960,190,560,82,ink,{rx:41}),
 X('title',960,190,'B R O A D W A Y',38,cream,{weight:700}),
 ...Array.from({length:12},(_,i)=>{const x=330+i*115,y=880+(i%2)*26;return [C('aud'+i,x,y,30,deep,{o:.92}),R('aub'+i,x,y+70,100,70,deep,{rx:35,o:.92})]}).flat()]}
case 2:return [
 R('screen',640,470,640,410,deep,{rx:26,sh:1}),
 R('display',640,460,590,350,cream,{rx:12}),
 R('base',640,700,780,36,wood,{rx:18}),R('notch',640,688,140,12,'#8C6649',{rx:6}),
 ...[300,210,340,170,260].map((w,i)=>{const ww=w*ap(t,.6+i*.45,.7);return R('ln'+i,385+ww/2,345+i*52,ww,14,[rust,gold,ink,gold,rust][i],{rx:7})}),
 R('caret',392+[300,210,340,170,260][Math.min(4,Math.floor(cl((t-.6)/.45,0,4)))]*1,345+Math.min(4,Math.floor(cl((t-.6)/.45,0,4)))*52,4,28,ink,{rx:2,o:Math.floor(t*2)%2}),
 R('enCard',1210,360,230,150,cream,{rx:28,stroke:ink,sw:5,sh:1,rot:-4}),
 X('en',1210,360,'EN',70,ink,{weight:800,rot:-4}),
 R('zhCard',1520,640,260,160,rust,{rx:28,sh:1,rot:3,s:.92+.08*ap(t,2.4,.8)}),
 X('zh',1520,640,'中文',66,cream,{weight:800,rot:3,o:ap(t,2.4,.8)}),
 P('arc','M1215 450 Q1230 640 1372 640',rust,{sw:8,dash:'14 14',off:-t*30}),
 P('arh','M1352 616 L1382 640 L1352 664',rust,{sw:8}),
 I('note0','note',1450,330+fl(t,0,18),1,{fill:gold,rot:-8})];
case 3:return [
 ...clock(560,530,t,ink,60),
 ...[0,1,2,3].map(i=>R('paper'+i,1230+i*24,500-i*18,470,380,cream,{rx:16,stroke:edge,sw:3,sh:1,rot:-7+i*7/3,o:ap(t,.2+i*.5,.6)})),
 ...[[gold,300],[ink,250],[rust,330],[ink,190]].map(([c,w]:any,j)=>{const ww=w*ap(t,2.4+j*.6,.7);return R('pl'+j,1117+ww/2,336+j*64,ww,12,c,{rx:6})}),
 I('pen','pen',1560,650+fl(t,1,10),1,{fill:rust,c2:gold,rot:-35})];
case 4:{const L=['但亚历山大 初次见面就被你吸引沉醉','这感觉从未体会','你身形憔悴 双眼充满智慧','当你见面说嗨 我忘记是非','火焰包围 将我撕碎','没办法回退'];
 const songT=t-9.35,starts=[0,7.1,10.1,16.2,22.2,26.1],ends=[7.1,10.1,16.2,22.2,26.1,29];
 const cur=Math.max(0,starts.filter(v=>songT>=v).length-1),cp=cl((songT-starts[cur])/(ends[cur]-starts[cur])),ex=400+strW(L[cur])*cp,ly=380+cur*82;
 return [
 R('paper0',985,575,1240,720,cream,{rx:18,stroke:edge,sw:3,rot:2.6,o:.8}),
 R('paper1',975,568,1240,720,cream,{rx:18,stroke:edge,sw:3,rot:-1.6,o:.9}),
 R('paper2',968,562,1240,720,cream,{rx:18,stroke:edge,sw:3,rot:1.1}),
 R('paper3',960,560,1240,720,cream,{rx:18,stroke:edge,sw:3,sh:1}),
 X('ptitle',400,262,'SATISFIED  ·  手译手稿',30,rust,{anchor:'start',ls:3,weight:700}),
 R('prule',960,304,1120,3,edge,{rx:2}),
 ...L.flatMap((l,i)=>{const p=cl((songT-starts[i])/(ends[i]-starts[i]));const chars=Array.from(l);return [X('guide'+i,400,380+i*82,l,40,ink,{anchor:'start',o:.16}),R('hl'+i,400+strW(l)*p/2,414+i*82,strW(l)*p,5,gold,{rx:2,o:.8}),...chars.map((ch,j)=>X('lyr'+i+'_'+j,400+strW(chars.slice(0,j).join('')),380+i*82,ch,40,rust,{anchor:'start',weight:700,o:cl(p*chars.length-j,0,1)}))]}),
 I('pen','pen',ex+44+(t>7.8?fl(t,1,6):0),ly-58,.9,{fill:rust,c2:gold,rot:30,o:songT>=0?1:0})]}
case 5:{const pc=[470,540];return [
 R('paper3',pc[0],pc[1],400,520,cream,{rx:18,stroke:edge,sw:3,rot:-6,sh:1}),
 ...[260,200,280,170,230].map((w,i)=>{const p=rp(pc[0],pc[1],-140+w/2,-170+i*70,-6);return R('pl'+i,p[0],p[1],w,12,i%2?gold:ink,{rx:6,rot:-6})}),
 P('arc','M700 620 Q930 770 1150 620',rust,{sw:8,dash:'14 14',off:-t*30}),
 X('q',935,420+fl(t,2,8),'?',140,gold,{weight:800,rot:Math.sin(t*1.3)*6}),
 I('bot0','bot',1360,480+fl(t,0,10),1.5,{fill:rust,c2:gold,e:blink(t)}),
 X('bot0l',1360,700,'AI',34,ink,{weight:800,ls:4}),
 X('title',960,900,'能跟着原曲唱吗？',46,ink,{weight:700})]}
case 6:case 7:case 8:{const act=id-6;return [
 H('title','从例子，到评分，再到整首歌'),
 ...[0,1,2].flatMap(i=>{const x=440+i*520,y=560,on=i===act,done=i<=act,co=done?1:.4;const nodes:any[]=[
  R(i===0?'paper3':'card'+i,x,y,380,440,cream,{rx:26,stroke:on?rust:edge,sw:on?6:3,sh:on?1.4:.5,s:on?1.04:1,o:done?1:.6}),
  X('ct'+i,x,y-160,['英 ↔ 中','评分模型','整曲调整'][i],34,on?rust:ink,{weight:700,o:co}),
  R('cd'+i,x,y-118,300,3,edge,{rx:2,o:co})];
  if(i===0)nodes.push(X('c0a',x,y-20,'A → 字',46,ink,{weight:700,o:co}),X('c0b',x,y+80,'B → 词',46,rust,{weight:700,o:co}));
  if(i===1)[70,120,95,170].forEach((h0,j)=>{const h=h0*(act>=1?1:.4);nodes.push(R('c1b'+j,x-120+j*80,y+150-h/2,46,h,j%2?rust:gold,{rx:10,o:co}))});
  if(i===2)nodes.push(I('c2n','note',x,y+10+fl(t,2,10),.8,{fill:act===2?rust:ink,o:co}),P('c2a','M'+(x-130)+' '+(y+130)+' Q'+x+' '+(y+190)+' '+(x+130)+' '+(y+130),gold,{sw:7,o:co}));
  if(i<2)nodes.push(P('ar'+i,'M'+(x+218)+' '+y+' H'+(x+300)+' M'+(x+280)+' '+(y-20)+' L'+(x+302)+' '+y+' L'+(x+280)+' '+(y+20),i<act?rust:tan,{sw:7}));
  return nodes}),
 X('cite',960,930,'Ye · Li · Xu / 2024',28,rust,{ls:3})]}
case 9:case 10:{const q=io((t-5)/1.6);return [
 H('title','10 个位置，13 个字'),
 ...Array.from({length:10},(_,i)=>R('cell'+i,292+i*148,510,124,150,cream,{rx:20,stroke:mixC(gold,rust,q),sw:4,sh:.6})),
 ...Array.from({length:13},(_,i)=>{const x0=i<10?292+i*148:292+(i-6.5)*148,y0=i<10?510:730,x1=292+i*111,x=x0+(x1-x0)*q,y=y0+(510-y0)*q+Math.sin(t*2+i)*4;return [C('tok'+i,x,y,38-8*q,i>9?rust:gold,{sh:.6}),X('tokn'+i,x,y,String(i+1),26-4*q,cream,{weight:800})]}).flat(),
 P('ruler','M240 830 H1680',ink,{sw:3}),
 P('rtk',Array.from({length:21},(_,i)=>'M'+(245+i*71)+' 816 V'+(i%2?844:852)).join(' '),ink,{sw:4}),
 X('cap',960,935,'字数挤进节拍，演唱就会拥挤',34,rust,{weight:700,o:ap(t,5.6,.6)})]}
case 11:return [
 H('title','重音 · 停顿 · 押韵'),
 R('base',960,652,1440,4,tan,{rx:2}),
 ...Array.from({length:12},(_,i)=>{const acc=i%4===0,x=272+i*122,h=(acc?250:170)*(.86+.14*Math.sin(t*3-i*.6));return [R('cell'+i,x,640-h/2,64,h,acc?rust:gold,{rx:22}),...(acc?[P('car'+i,'M'+(x-18)+' '+(612-h)+' L'+x+' '+(586-h)+' L'+(x+18)+' '+(612-h),rust,{sw:7})]:[])]}).flat(),
 R('ps0',690,540,8,240,green,{rx:4}),R('ps1',712,540,8,240,green,{rx:4}),
 X('psl',701,730,'停顿',32,green,{weight:700})];
case 12:return [
 H('title','韵脚，也藏在句中'),
 ...[0,1,2].flatMap(r=>[...Array.from({length:12},(_,i)=>{const hot=i===4||i===10;return R(r===0?'cell'+i:'g'+r+'_'+i,288+i*122,370+r*190,80,80,hot?rust:sand,{rx:16,s:hot?1+.06*Math.sin(t*3+r):1,o:r===0?1:ap(t,.4+r*.3+i*.03,.5)})}),
  P('arc'+r,'M'+(288+4*122)+' '+(326+r*190)+' Q'+(288+7*122)+' '+(206+r*190)+' '+(288+10*122)+' '+(326+r*190),gold,{sw:5,dash:'12 10',off:-t*20,o:ap(t,1.2+r*.4,.6)})]),
 X('cap',960,950,'句中韵 + 句尾韵',32,rust,{weight:700,ls:2})];
case 13:{const cx=960,cy=570,R0=270,ang=(i:number)=>-Math.PI/2+i*2*Math.PI/5,pt=(i:number,r:number)=>[cx+r*Math.cos(ang(i)),cy+r*Math.sin(ang(i))];
 const vals=[.92,.78,.86,.95,.72].map((v,i)=>v*(.25+.75*ap(t,.6+i*.2,1.2))*(1+.03*Math.sin(t*1.5+i)));
 const poly=(fn:(i:number)=>number)=>[0,1,2,3,4].map(i=>(i?'L':'M')+pt(i,fn(i)).map(v=>v.toFixed(1)).join(' ')).join(' ')+'Z';
 return [
 ...[1,.66,.33].map((k,j)=>P('ring'+j,poly(()=>R0*k),j===0?tan:sand,{fill:j===0?cream:'none',sw:3})),
 ...[0,1,2,3,4].map(i=>{const p=pt(i,R0);return P('spk'+i,'M'+cx+' '+cy+' L'+p[0].toFixed(1)+' '+p[1].toFixed(1),sand,{sw:3})}),
 P('polyF',poly(i=>R0*vals[i]),null,{fill:gold,o:.32}),
 P('polyS',poly(i=>R0*vals[i]),gold,{sw:5}),
 ...[0,1,2,3,4].map(i=>{const p=pt(i,R0*vals[i]);return C('dot'+i,p[0],p[1],18,rust,{stroke:cream,sw:5})}),
 ...['唱得顺','意思到位','措辞自然','节奏合拍','兼顾押韵'].map((l,i)=>{const p=pt(i,R0+(i===0?62:115));return X('rl'+i,p[0],p[1],l,36,ink,{weight:700,o:ap(t,1+i*.2,.6)})}),
 R('pill',cx,cy,230,76,cream,{rx:38,sh:.6}),
 X('title',cx,cy,'五项全能',44,ink,{weight:800}),
 X('cite',960,975,'Peter Low / 2003',28,rust,{ls:3})]}
case 14:return [
 H('title','把约束变成可控的边界'),
 ...['长度','韵脚','词语'].flatMap((l,i)=>{const y=400+i*170,v0=.35+.2*i,v=v0+.12*Math.sin(t*.7+i*1.3),kx=600+920*v;return [
  X('sl'+i,420,y,l,40,ink,{weight:700}),
  R('tr'+i,1060,y,920,14,sand,{rx:7}),
  R('band'+i,600+920*v0,y,920*.32,40,green,{rx:20,o:.14}),
  R('blo'+i,600+920*(v0-.16),y,6,56,green,{rx:3}),R('bhi'+i,600+920*(v0+.16),y,6,56,green,{rx:3}),
  R('tf'+i,600+(kx-600)/2,y,kx-600,14,rust,{rx:7}),
  C('dot'+i,kx,y,26,gold,{stroke:cream,sw:6,sh:.8})]}),
 X('cite',960,960,'Ou · Ma · Kan · Wang / 2023',28,rust,{ls:3})];
case 15:case 16:case 17:{const act=id-15;const ics=['M-22 2 L-6 18 L24 -16','M0 -26 V26 M-26 0 H26 M-18 -18 L18 18 M18 -18 L-18 18','M-24 0 A24 24 0 1 0 24 0 A24 24 0 1 0 -24 0 M-40 0 H40 M0 -40 V40'];return [
 X('shot',600,540,'SHOT',200,ink,{weight:800,ls:6}),
 R('shotU',600,650,420,10,gold,{rx:5}),
 ...[0,1,2].flatMap(i=>{const y=300+i*240,on=i<=act,c=[gold,rust,green][i];return [
  P('br'+i,'M905 540 C1040 540 1080 '+y+' 1238 '+y,on?c:tan,{sw:6,o:on?1:.4}),
  C('dot'+i,1310,y,62,on?c:sand,{sh:on?.8:0,s:i===act?1+.04*Math.sin(t*3):1}),
  P('ic'+i,ics[i],cream,{x:1310,y,sw:8,o:on?1:.6}),
  X('bl'+i,1410,y,['机会','革命中的枪','决斗的伏笔'][i],38,ink,{anchor:'start',weight:700,o:on?1:.3})]}),
 X('cap',600,780,'一词，三层意思',42,rust,{weight:700,o:act===2?1:0})]}
case 18:{const a=Math.sin(t*.65)*6,ar=a*Math.PI/180,px=960,py=430,L=380,pts=[[px-L*Math.cos(ar),py-L*Math.sin(ar)],[px+L*Math.cos(ar),py+L*Math.sin(ar)]];return [
 H('title','在有限的一句里做取舍'),
 R('post',960,610,26,360,ink,{rx:13}),R('foot',960,800,520,40,ink,{rx:20}),
 ...pts.flatMap(([x,y],i)=>{const c=i?rust:gold;return [
  P('str'+i,'M'+x.toFixed(1)+' '+y.toFixed(1)+' L'+(x-120).toFixed(1)+' '+(y+190).toFixed(1)+' M'+x.toFixed(1)+' '+y.toFixed(1)+' L'+(x+120).toFixed(1)+' '+(y+190).toFixed(1),tan,{sw:4}),
  C('dot'+i,x,y+148,44,c,{sh:.6}),
  R('pan'+i,x,y+200,310,26,c,{rx:13}),
  X('pl'+i,x,y+270,i?'合拍押韵':'多层词义',38,ink,{weight:700})]}),
 R('beam',px,py,2*L+40,22,ink,{rx:11,rot:a}),
 C('pivot',px,py,22,gold,{stroke:ink,sw:5})]}
case 19:{const m=Math.abs(Math.sin(t*2.2)),ih=60+m*170;return [
 H('title','口型，也是旋律的一部分'),
 E('lip',960,540,540,160+m*190,rust,{sh:1}),
 E('mouthIn',960,546,420,ih,deep),
 R('teeth',960,546-ih/2+16,280,24,cream,{rx:12,o:cl(ih/80)}),
 E('tongue',960,546+ih/2-18,220,10+m*40,clay,{o:cl(ih/80)}),
 ...[0,1,2].flatMap(i=>{const o=.2+.65*Math.max(0,Math.sin(t*4-i));return [P('swR'+i,'M'+(1300+i*70)+' '+(450-i*22)+' Q'+(1370+i*80)+' 540 '+(1300+i*70)+' '+(630+i*22),gold,{sw:8,o}),P('swL'+i,'M'+(620-i*70)+' '+(450-i*22)+' Q'+(550-i*80)+' 540 '+(620-i*70)+' '+(630+i*22),gold,{sw:8,o})]}),
 X('word',960,850,'sh · o · t',52,ink,{weight:700,ls:4})]}
case 20:{const k=t/2.2,ki=Math.floor(k),act=ki%5,fr=k-ki,hx0=300+330*(act+(act<4&&fr>.8?io((fr-.8)/.2):0));return [
 H('title','让不同的智能体，各司其职'),
 R('rail',960,520,1320,6,tan,{rx:3}),
 C('halo',hx0,500,135,gold,{o:.16}),
 ...['通读','韵律','翻译','审核','返修'].flatMap((l,i)=>{const on=i===act,x=300+i*330;return [
  I('bot'+i,'bot',x,500+fl(t,i,6),on?1.05:.85,{fill:on?rust:mute,c2:gold,e:blink(t,i)}),
  X('bot'+i+'l',x,690,l,32,on?rust:ink,{weight:700})]}),
 R('trk',960,800,1320,6,sand,{rx:3}),
 C('pkt',300+(t*150%1320),800,14,rust,{stroke:cream,sw:4})]}
case 21:return [
 I('bot0','bot',420,500+fl(t,0,8),1.45,{fill:rust,c2:gold,e:blink(t)}),
 X('bot0l',420,740,'通读智能体',36,ink,{weight:700}),
 R('paper3',1150,540,820,620,cream,{rx:22,stroke:edge,sw:3,sh:1}),
 X('ptitle',800,300,'翻译说明',42,ink,{anchor:'start',weight:800}),
 R('prule',1150,350,700,3,edge,{rx:2}),
 ...['角色语气','段落情境','双关与伏笔'].flatMap((l,i)=>{const a=ap(t,1+i*1.6,.7),y=440+i*130,w=(420+i*40)*ap(t,1.5+i*1.6,.8);return [C('bul'+i,825,y,15,rust,{o:a}),X('it'+i,860,y,l,40,ink,{anchor:'start',weight:700,o:a}),R('iu'+i,860+w/2,y+46,w,10,gold,{rx:5,o:.7})]}),
 P('feed','M600 500 C660 500 680 540 730 540',rust,{sw:7,dash:'12 12',off:-t*30})];
case 22:{const sx=240+(t*90%1340);return [
 H('title','标记句中韵、句尾韵和停顿'),
 ...[0,1,2,3].flatMap(r=>[...Array.from({length:11},(_,i)=>{const x=300+i*120,hot=i===3||i===10,near=Math.abs(x-sx)<60;return R('g'+r+'_'+i,x,360+r*135,76,70,hot?(r%2?green:rust):sand,{rx:14,s:near?1.1:1,o:ap(t,.2+r*.2+i*.03,.5)})}),R('pz'+r,960,360+r*135,6,96,gold,{rx:3})]),
 R('scan',sx,560,6,600,rust,{rx:3,o:.75})]}
case 23:{const cur=Math.floor(t*1.2)%12,ys=[2,4,7,3,5,8,4,6,1,5,3,6];return [
 R('paper3',960,540,1320,620,cream,{rx:22,stroke:edge,sw:3,sh:1}),
 ...[0,1,2,3,4].map(i=>R('st'+i,960,420+i*36,1180,3,'#B89B77',{rx:2})),
 ...[370,765,1155,1550].map((x,j)=>R('bar'+j,x,492,4,148,'#B89B77',{rx:2})),
 ...ys.map((k,i)=>{const on=i===cur;return I('n'+i,'note1',440+i*90+Math.floor(i/4)*30,402+k*18-(on?10*Math.abs(Math.sin(t*6)):0),.8,{fill:on?rust:ink,o:ap(t,.2+i*.1,.4)})}),
 X('cap',960,730,'手动校正 → 更明确的节奏依据',34,rust,{weight:700}),
 I('pen','pen',1560,770+fl(t,1,10),1,{fill:rust,c2:gold,rot:-30})]}
case 24:return [
 I('bot2','bot',400,480+fl(t,0,8),1.4,{fill:rust,c2:gold,e:blink(t,2)}),
 X('bot2l',400,710,'翻译智能体',36,ink,{weight:700}),
 R('paper3',1160,540,840,620,cream,{rx:22,stroke:edge,sw:3,sh:1}),
 X('ptitle',1160,300,'上下文 + 韵律 → 填词',40,ink,{weight:800}),
 ...Array.from({length:5},(_,r)=>Array.from({length:10},(_,i)=>R('f'+r+'_'+i,830+i*74,400+r*76,50,46,i===9?rust:gold,{rx:9,o:.15+.85*ap(t,.5+r*1.1+i*.08,.3)}))).flat(),
 P('feed','M560 480 C640 480 660 540 730 540',rust,{sw:7,dash:'12 12',off:-t*30})];
case 25:case 26:{const fix=id===26;return [
 H('title',fix?'未通过的句子，退回重写':'程序检查 + 语义审核'),
 R('paper3',620,560,580,520,cream,{rx:22,stroke:edge,sw:3,sh:1}),
 R('badhl',620,492,520,84,rust,{rx:16,o:fix?.12:0}),
 ...['音节数','韵脚','意思','角色语气'].flatMap((l,i)=>{const y=380+i*112,bad=fix&&i===1,a=fix?1:ap(t,.5+i*.5,.5);return [
  X('ck'+i,400,y,l,38,ink,{anchor:'start',weight:700}),
  C('cb'+i,800,y,30,bad?rust:green,{o:a,s:.6+.4*a}),
  P('cm'+i,bad?'M-12 -12 L12 12 M12 -12 L-12 12':'M-14 0 L-4 11 L15 -11',cream,{x:800,y,sw:7,o:a})]}),
 I('bot3','bot',1340,500+fl(t,0,8),1.45,{fill:fix?green:rust,c2:gold,e:blink(t,3)}),
 X('bot3l',1340,740,fix?'返修智能体':'审核智能体',36,ink,{weight:700}),
 P('ret','M1250 690 Q1120 900 880 800',rust,{sw:7,dash:'16 12',off:-t*40,o:fix?1:0}),
 P('reth','M900 776 L874 800 L906 812',rust,{sw:7,o:fix?1:0})]}
case 27:return [
 ...clock(560,520,t,gold,90),
 X('big',1260,470,'40–60',150,ink,{weight:800}),
 X('unit',1260,600,'分钟 / 首',44,rust,{weight:700}),
 ...[0,1,2].map(i=>R('rb'+i,1110+i*150,730+fl(t,i,8),110,64,i===1?gold:rust,{rx:14})),
 X('cap',960,920,'同组韵脚，一起重新规划',36,ink,{weight:700})];
case 28:return [
 R('display',960,540,1240,600,deep,{rx:30,sh:1}),
 R('wl',960,314,1240,3,'#5A4032',{rx:0}),
 C('w0',384,277,11,rust),C('w1',424,277,11,gold),C('w2',464,277,11,green),
 X('brace',960,470,'{ }',120,gold,{weight:800}),
 X('repo',960,610,'rxtech-lab / lyrics-translation',46,cream,{weight:700}),
 X('url',960,690,'github.com/rxtech-lab/lyrics-translation',28,'#DDC8A8'),
 X('cap',960,940,'开源，让实验继续',38,ink,{weight:700})];
case 29:{const rot=t*40;return [
 X('title',960,150,'听见中文，跟上旋律',56,ink,{weight:700}),
 R('display',960,510,540,540,deep,{rx:270,sh:1}),
 ...[222,188,154].map((r,i)=>C('gr'+i,960,510,r,'none',{stroke:'#5A4032',sw:3})),
 P('sheen','M-215 -60 A222 222 0 0 1 -60 -215',cream,{x:960,y:510,sw:10,o:.14}),
 C('lab',960,510,95,rust),
 P('mark','M0 -80 L0 -52',cream,{x:960,y:510,rot,sw:8}),
 C('spin',960,510,14,cream),
 ...Array.from({length:48},(_,i)=>{const h=20+Math.abs(Math.sin(i*.7+t*3)*Math.cos(i*.2-t))*120;return R('wb'+i,400+i*23.8,880,12,h,i%6===0?rust:gold,{rx:6})}),
 I('note0','note',420,430+fl(t,0,14),1.15,{fill:gold,rot:-8}),
 I('note1','note',1500,570-fl(t,1,14),1,{fill:rust,rot:8})]}
case 30:return [
 H('title','下一站：整张专辑'),
 ...Array.from({length:7},(_,i)=>{const x=360+i*200,y=540+Math.sin(t*.6+i*.9)*22,r=(i-3)*3,a=ap(t,.2+i*.12,.6),sp=rp(x,y,0,-30,r),np=rp(x,y,0,100,r);return [
  R(i===3?'display':'alb'+i,x,y,190,300,i%2?rust:gold,{rx:16,rot:r,stroke:cream,sw:5,sh:1,o:i===3?1:a}),
  I('as'+i,'star',sp[0],sp[1],.45,{fill:cream,rot:r,o:a}),
  X('an'+i,np[0],np[1],String(i+1).padStart(2,'0'),28,cream,{weight:800,rot:r,o:a})]}).flat(),
 X('cap',960,880,'不同曲风，继续试唱',36,ink,{weight:700})];
case 31:return [
 H('title','成本，随模型和返工轮数变化'),
 ...['订阅','API'].flatMap((l,i)=>{const x=640+i*640,y=540,cnt=i?[2,4,6]:[3,3,3];return [
  R('alb'+(2+i*2),x,y,460,460,cream,{rx:28,stroke:edge,sw:3,sh:1,rot:i?2.5:-2.5}),
  X('cl'+i,x,y-150,l,52,ink,{weight:800}),
  ...[0,1,2].flatMap(j=>Array.from({length:cnt[j]},(_,k)=>E('coin'+i+'_'+j+'_'+k,x-110+j*110,y+150-k*22,84,30,gold,{stroke:'#A86F22',sw:3,o:ap(t,.5+j*.3+k*.15,.3)})))]}),
 X('cap',960,900,'模型选择 × 修改轮数',36,rust,{weight:700})];
case 32:return [
 H('title','同一段歌词，交给不同模型'),
 ...['A','B','C'].flatMap((l,i)=>{const x=450+i*510,c=[rust,gold,green][i];return [
  I('bot'+i,'bot',x,420+fl(t,i,8),1.15,{fill:c,c2:i===1?cream:gold,e:blink(t,i)}),
  X('bot'+i+'l',x,590,'模型 '+l,34,ink,{weight:700}),
  ...Array.from({length:8},(_,j)=>{const h=40+Math.abs(Math.sin(t*1.3+j*.8+i*2))*120;return R('mb'+i+'_'+j,x-140+j*40,780-h/2,22,h,c,{rx:11})}),
  X('mc'+i,x,860,'试唱 · 效果 · 成本',28,'#7A5A44')]})];
case 34:{const refs=[
 ['Zhuorui Ye, Jinhan Li & Rongwu Xu（2024）',
  'Sing it, Narrate it: Quality Musical Lyrics Translation。',
  'Findings of EMNLP 2024，5498–5520。'],
 ['Peter Low（2003）',
  'Singable translations of songs。',
  'Perspectives，11(2)，87–103。'],
 ['Longshen Ou, Xichu Ma, Min-Yen Kan & Ye Wang（2023）',
  'Songs Across Borders: Singable and Controllable Neural Lyric Translation。',
  'ACL 2023，447–467。'],
 ['Jason C. McCool（2020）',
  'Radical Reclamations and Musical Resonances in Hamilton:',
  'An American Musical。波士顿大学博士论文，第 145 页。']
];return [
 R('refpaper',960,540,1680,920,cream,{rx:24,stroke:edge,sw:3,sh:1}),
 X('reftitle',220,170,'参考文献',52,ink,{anchor:'start',weight:700}),
 R('refrule',960,226,1480,3,edge,{rx:1}),
 ...refs.flatMap((lines,i)=>{const y=300+i*170;return [
 X('refnum'+i,220,y,'〔'+(i+1)+'〕',32,rust,{anchor:'start',weight:700}),
 ...lines.map((line,j)=>X('ref'+i+'_'+j,320,y+j*44,line,j===0?32:30,j===0?ink:deep,{anchor:'start',weight:j===0?700:400}))
 ];})
 ];}
default:return [
 C('halo2',960,400,320,gold,{o:.06}),
 C('halo',960,400,240,gold,{o:.13+.04*Math.sin(t*1.5)}),
 I('star','star',960,400,1.3+.03*Math.sin(t*1.6),{fill:gold,rot:Math.sin(t*.7)*4}),
 X('title',960,690,'下一首，继续唱',76,ink,{weight:700}),
 R('rule',960,752,160*ap(t,.6,.8),5,rust,{rx:3}),
 X('sub',960,805,'感谢收听 · 下次见',32,rust,{ls:6})];
}};

const frameSvg=(fr:number)=>{const s=fr/30;let ci=0;for(let i=0;i<cues.length;i++)if(s>=cues[i].at)ci=i;
 const cur=cues[ci],t=s-cur.at,u=t/D,B=scene(cur.id,t);
 const A=u<1?(ci>0?scene(cues[ci-1].id,s-cues[ci-1].at):[]):null;
 return <svg viewBox="0 0 1920 1080" width="1920" height="1080"><defs><radialGradient id="bg" cx=".5" cy=".42" r=".75"><stop offset="0" stopColor="#FFF4E0"/><stop offset="1" stopColor="#E8CDA4"/></radialGradient><pattern id="grain" width="80" height="80" patternUnits="userSpaceOnUse"><circle cx="12" cy="16" r="1.1" fill="#7B5233" opacity=".1"/><circle cx="53" cy="62" r=".9" fill="#7B5233" opacity=".08"/><circle cx="66" cy="21" r=".7" fill="#7B5233" opacity=".07"/></pattern></defs>
 <rect width="1920" height="1080" fill="url(#bg)"/><rect width="1920" height="1080" fill="url(#grain)"/>
 <circle cx={f2(1790+Math.sin(s*.05)*40)} cy={f2(90+Math.cos(s*.04)*30)} r="300" fill={gold} opacity=".07"/>
 <circle cx={f2(120+Math.cos(s*.05)*40)} cy={f2(1000+Math.sin(s*.03)*30)} r="340" fill={rust} opacity=".05"/>
 {compose(A,B,u)}</svg>};

const KEEP=new Set(['viewBox','patternUnits','gradientUnits','preserveAspectRatio','gradientTransform','patternTransform']);
const esc=(v:any)=>String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
function xml(node:any):string {
 if(node==null||typeof node==='boolean')return '';
 if(Array.isArray(node))return node.map(xml).join('');
 if(typeof node==='string'||typeof node==='number')return esc(node);
 if(typeof node.type==='function')return xml(node.type(node.props));
 if(typeof node.type==='symbol')return xml(node.props.children);
 const p=node.props||{};
 const attrs=Object.keys(p).filter(k=>k!=='children'&&k!=='key'&&k!=='style'&&p[k]!=null).map(k=>' '+(KEEP.has(k)?k:k.replace(/[A-Z]/g,m=>'-'+m.toLowerCase()))+'="'+esc(p[k])+'"').join('');
 return '<'+node.type+attrs+'>'+xml(p.children)+'</'+node.type+'>';
}
export const MyComposition:React.FC=()=>{const fr=useCurrentFrame();const str=xml(frameSvg(fr)).replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" font-family="PingFang SC, Helvetica Neue, sans-serif" ');return <AbsoluteFill style={{backgroundColor:'#F1DFC4'}}><img src={'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(str)} style={{width:'100%',height:'100%',objectFit:'contain'}}/></AbsoluteFill>};
